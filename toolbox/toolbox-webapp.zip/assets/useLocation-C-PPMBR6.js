import{b6 as t}from"./index-CuBDL_H4.js";function l(e){return t({select:o=>e!=null&&e.select?e.select(o.location):o.location})}export{l as u};
