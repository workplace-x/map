import{aA as o}from"./index-CuBDL_H4.js";const a=o;export{a as component};
