import{b3 as t,j as e}from"./index-CuBDL_H4.js";/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var n=t("outline","planet","IconPlanet",[["path",{d:"M18.816 13.58c2.292 2.138 3.546 4 3.092 4.9c-.745 1.46 -5.783 -.259 -11.255 -3.838c-5.47 -3.579 -9.304 -7.664 -8.56 -9.123c.464 -.91 2.926 -.444 5.803 .805",key:"svg-0"}],["path",{d:"M12 12m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0",key:"svg-1"}]]);function s(){return e.jsx("div",{className:"h-svh",children:e.jsxs("div",{className:"m-auto flex h-full w-full flex-col items-center justify-center gap-2",children:[e.jsx(n,{size:72}),e.jsx("h1",{className:"text-4xl leading-tight font-bold",children:"Coming Soon 👀"}),e.jsxs("p",{className:"text-muted-foreground text-center",children:["This page has not been created yet. ",e.jsx("br",{}),"Stay tuned though!"]})]})})}const a=s;export{a as component};
