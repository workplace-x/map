import{V as o}from"./VendorDetails-B4KJbSLj.js";import"./index-CuBDL_H4.js";import"./arrow-left-3n1luWhI.js";import"./zap-D6KLvFAs.js";import"./circle-x-p_-h4WRw.js";const n=o;export{n as component};
