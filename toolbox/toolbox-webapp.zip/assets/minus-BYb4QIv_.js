import{f as o}from"./index-CuBDL_H4.js";/**
 * @license lucide-react v0.488.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"M5 12h14",key:"1ays0h"}]],e=o("minus",s);export{e as M};
