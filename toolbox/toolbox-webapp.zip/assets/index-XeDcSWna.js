import{b3 as a,j as e,r as o,af as k,ae as u,ac as x,B as M}from"./index-CuBDL_H4.js";import{S as r,a as i,b as h,c as m,d as n}from"./select-BswIsgfx.js";import{S as j}from"./separator-Chrr1zzT.js";import{H as f,M as b}from"./main-Dyhe9R0W.js";import{S as I}from"./search-Couanuy3.js";import{I as S}from"./IconBrandGithub-rASeXry2.js";import"./index-DgQtbRN0.js";import"./sidebar-CltTWTBU.js";import"./index-B49goZjw.js";import"./x-DcfoarZ4.js";import"./search-context-BFK4GVN7.js";import"./command-Ca16-8Bg.js";import"./dialog-BRQs-hig.js";import"./bot-Bmn-JysZ.js";import"./file-text-CoPXWk81.js";import"./user-Bxszi5i7.js";import"./circle-help-_UQahqY4.js";/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var B=a("outline","adjustments-horizontal","IconAdjustmentsHorizontal",[["path",{d:"M14 6m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",key:"svg-0"}],["path",{d:"M4 6l8 0",key:"svg-1"}],["path",{d:"M16 6l4 0",key:"svg-2"}],["path",{d:"M8 12m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",key:"svg-3"}],["path",{d:"M4 12l2 0",key:"svg-4"}],["path",{d:"M10 12l10 0",key:"svg-5"}],["path",{d:"M17 18m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",key:"svg-6"}],["path",{d:"M4 18l11 0",key:"svg-7"}],["path",{d:"M19 18l1 0",key:"svg-8"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var z=a("outline","brand-discord","IconBrandDiscord",[["path",{d:"M8 12a1 1 0 1 0 2 0a1 1 0 0 0 -2 0",key:"svg-0"}],["path",{d:"M14 12a1 1 0 1 0 2 0a1 1 0 0 0 -2 0",key:"svg-1"}],["path",{d:"M15.5 17c0 1 1.5 3 2 3c1.5 0 2.833 -1.667 3.5 -3c.667 -1.667 .5 -5.833 -1.5 -11.5c-1.457 -1.015 -3 -1.34 -4.5 -1.5l-.972 1.923a11.913 11.913 0 0 0 -4.053 0l-.975 -1.923c-1.5 .16 -3.043 .485 -4.5 1.5c-2 5.667 -2.167 9.833 -1.5 11.5c.667 1.333 2 3 3.5 3c.5 0 2 -2 2 -3",key:"svg-2"}],["path",{d:"M7 16.5c3.5 1 6.5 1 10 0",key:"svg-3"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var N=a("outline","brand-docker","IconBrandDocker",[["path",{d:"M22 12.54c-1.804 -.345 -2.701 -1.08 -3.523 -2.94c-.487 .696 -1.102 1.568 -.92 2.4c.028 .238 -.32 1 -.557 1h-14c0 5.208 3.164 7 6.196 7c4.124 .022 7.828 -1.376 9.854 -5c1.146 -.101 2.296 -1.505 2.95 -2.46z",key:"svg-0"}],["path",{d:"M5 10h3v3h-3z",key:"svg-1"}],["path",{d:"M8 10h3v3h-3z",key:"svg-2"}],["path",{d:"M11 10h3v3h-3z",key:"svg-3"}],["path",{d:"M8 7h3v3h-3z",key:"svg-4"}],["path",{d:"M11 7h3v3h-3z",key:"svg-5"}],["path",{d:"M11 4h3v3h-3z",key:"svg-6"}],["path",{d:"M4.571 18c1.5 0 2.047 -.074 2.958 -.78",key:"svg-7"}],["path",{d:"M10 16l0 .01",key:"svg-8"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var w=a("outline","brand-figma","IconBrandFigma",[["path",{d:"M15 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0",key:"svg-0"}],["path",{d:"M6 3m0 3a3 3 0 0 1 3 -3h6a3 3 0 0 1 3 3v0a3 3 0 0 1 -3 3h-6a3 3 0 0 1 -3 -3z",key:"svg-1"}],["path",{d:"M9 9a3 3 0 0 0 0 6h3m-3 0a3 3 0 1 0 3 3v-15",key:"svg-2"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var C=a("outline","brand-gitlab","IconBrandGitlab",[["path",{d:"M21 14l-9 7l-9 -7l3 -11l3 7h6l3 -7z",key:"svg-0"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var A=a("outline","brand-gmail","IconBrandGmail",[["path",{d:"M16 20h3a1 1 0 0 0 1 -1v-14a1 1 0 0 0 -1 -1h-3v16z",key:"svg-0"}],["path",{d:"M5 20h3v-16h-3a1 1 0 0 0 -1 1v14a1 1 0 0 0 1 1z",key:"svg-1"}],["path",{d:"M16 4l-4 4l-4 -4",key:"svg-2"}],["path",{d:"M4 6.5l8 7.5l8 -7.5",key:"svg-3"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var T=a("outline","brand-medium","IconBrandMedium",[["path",{d:"M4 4m0 2a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2z",key:"svg-0"}],["path",{d:"M8 9h1l3 3l3 -3h1",key:"svg-1"}],["path",{d:"M8 15l2 0",key:"svg-2"}],["path",{d:"M14 15l2 0",key:"svg-3"}],["path",{d:"M9 9l0 6",key:"svg-4"}],["path",{d:"M15 9l0 6",key:"svg-5"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var D=a("outline","brand-notion","IconBrandNotion",[["path",{d:"M11 17.5v-6.5h.5l4 6h.5v-6.5",key:"svg-0"}],["path",{d:"M19.077 20.071l-11.53 .887a1 1 0 0 1 -.876 -.397l-2.471 -3.294a1 1 0 0 1 -.2 -.6v-10.741a1 1 0 0 1 .923 -.997l11.389 -.876a2 2 0 0 1 1.262 .33l1.535 1.023a2 2 0 0 1 .891 1.664v12.004a1 1 0 0 1 -.923 .997z",key:"svg-1"}],["path",{d:"M4.5 5.5l2.5 2.5",key:"svg-2"}],["path",{d:"M20 7l-13 1v12.5",key:"svg-3"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var G=a("outline","brand-skype","IconBrandSkype",[["path",{d:"M12 3a9 9 0 0 1 8.603 11.65a4.5 4.5 0 0 1 -5.953 5.953a9 9 0 0 1 -11.253 -11.253a4.5 4.5 0 0 1 5.953 -5.954a8.987 8.987 0 0 1 2.65 -.396z",key:"svg-0"}],["path",{d:"M8 14.5c.5 2 2.358 2.5 4 2.5c2.905 0 4 -1.187 4 -2.5c0 -1.503 -1.927 -2.5 -4 -2.5s-4 -1 -4 -2.5c0 -1.313 1.095 -2.5 4 -2.5c1.642 0 3.5 .5 4 2.5",key:"svg-1"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var E=a("outline","brand-slack","IconBrandSlack",[["path",{d:"M12 12v-6a2 2 0 0 1 4 0v6m0 -2a2 2 0 1 1 2 2h-6",key:"svg-0"}],["path",{d:"M12 12h6a2 2 0 0 1 0 4h-6m2 0a2 2 0 1 1 -2 2v-6",key:"svg-1"}],["path",{d:"M12 12v6a2 2 0 0 1 -4 0v-6m0 2a2 2 0 1 1 -2 -2h6",key:"svg-2"}],["path",{d:"M12 12h-6a2 2 0 0 1 0 -4h6m-2 0a2 2 0 1 1 2 -2v6",key:"svg-3"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var H=a("outline","brand-stripe","IconBrandStripe",[["path",{d:"M11.453 8.056c0 -.623 .518 -.979 1.442 -.979c1.69 0 3.41 .343 4.605 .923l.5 -4c-.948 -.449 -2.82 -1 -5.5 -1c-1.895 0 -3.373 .087 -4.5 1c-1.172 .956 -2 2.33 -2 4c0 3.03 1.958 4.906 5 6c1.961 .69 3 .743 3 1.5c0 .735 -.851 1.5 -2 1.5c-1.423 0 -3.963 -.609 -5.5 -1.5l-.5 4c1.321 .734 3.474 1.5 6 1.5c2 0 3.957 -.468 5.084 -1.36c1.263 -.979 1.916 -2.268 1.916 -4.14c0 -3.096 -1.915 -4.547 -5 -5.637c-1.646 -.605 -2.544 -1.07 -2.544 -1.807z",key:"svg-0"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var L=a("outline","brand-telegram","IconBrandTelegram",[["path",{d:"M15 10l-4 4l6 6l4 -16l-18 7l4 2l2 6l3 -4",key:"svg-0"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var F=a("outline","brand-trello","IconBrandTrello",[["path",{d:"M4 4m0 2a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2z",key:"svg-0"}],["path",{d:"M7 7h3v10h-3z",key:"svg-1"}],["path",{d:"M14 7h3v6h-3z",key:"svg-2"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var V=a("outline","brand-whatsapp","IconBrandWhatsapp",[["path",{d:"M3 21l1.65 -3.8a9 9 0 1 1 3.4 2.9l-5.05 .9",key:"svg-0"}],["path",{d:"M9 10a.5 .5 0 0 0 1 0v-1a.5 .5 0 0 0 -1 0v1a5 5 0 0 0 5 5h1a.5 .5 0 0 0 0 -1h-1a.5 .5 0 0 0 0 1",key:"svg-1"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var W=a("outline","brand-zoom","IconBrandZoom",[["path",{d:"M17.011 9.385v5.128l3.989 3.487v-12z",key:"svg-0"}],["path",{d:"M3.887 6h10.08c1.468 0 3.033 1.203 3.033 2.803v8.196a.991 .991 0 0 1 -.975 1h-10.373c-1.667 0 -2.652 -1.5 -2.652 -3l.01 -8a.882 .882 0 0 1 .208 -.71a.841 .841 0 0 1 .67 -.287z",key:"svg-1"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var Z=a("outline","sort-ascending-letters","IconSortAscendingLetters",[["path",{d:"M15 10v-5c0 -1.38 .62 -2 2 -2s2 .62 2 2v5m0 -3h-4",key:"svg-0"}],["path",{d:"M19 21h-4l4 -7h-4",key:"svg-1"}],["path",{d:"M4 15l3 3l3 -3",key:"svg-2"}],["path",{d:"M7 6v12",key:"svg-3"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var R=a("outline","sort-descending-letters","IconSortDescendingLetters",[["path",{d:"M15 21v-5c0 -1.38 .62 -2 2 -2s2 .62 2 2v5m0 -3h-4",key:"svg-0"}],["path",{d:"M19 10h-4l4 -7h-4",key:"svg-1"}],["path",{d:"M4 15l3 3l3 -3",key:"svg-2"}],["path",{d:"M7 6v12",key:"svg-3"}]]);const P=[{name:"Telegram",logo:e.jsx(L,{}),connected:!1,desc:"Connect with Telegram for real-time communication."},{name:"Notion",logo:e.jsx(D,{}),connected:!0,desc:"Effortlessly sync Notion pages for seamless collaboration."},{name:"Figma",logo:e.jsx(w,{}),connected:!0,desc:"View and collaborate on Figma designs in one place."},{name:"Trello",logo:e.jsx(F,{}),connected:!1,desc:"Sync Trello cards for streamlined project management."},{name:"Slack",logo:e.jsx(E,{}),connected:!1,desc:"Integrate Slack for efficient team communication"},{name:"Zoom",logo:e.jsx(W,{}),connected:!0,desc:"Host Zoom meetings directly from the dashboard."},{name:"Stripe",logo:e.jsx(H,{}),connected:!1,desc:"Easily manage Stripe transactions and payments."},{name:"Gmail",logo:e.jsx(A,{}),connected:!0,desc:"Access and manage Gmail messages effortlessly."},{name:"Medium",logo:e.jsx(T,{}),connected:!1,desc:"Explore and share Medium stories on your dashboard."},{name:"Skype",logo:e.jsx(G,{}),connected:!1,desc:"Connect with Skype contacts seamlessly."},{name:"Docker",logo:e.jsx(N,{}),connected:!1,desc:"Effortlessly manage Docker containers on your dashboard."},{name:"GitHub",logo:e.jsx(S,{}),connected:!1,desc:"Streamline code management with GitHub integration."},{name:"GitLab",logo:e.jsx(C,{}),connected:!1,desc:"Efficiently manage code projects with GitLab integration."},{name:"Discord",logo:e.jsx(z,{}),connected:!1,desc:"Connect with Discord for seamless team communication."},{name:"WhatsApp",logo:e.jsx(V,{}),connected:!1,desc:"Easily integrate WhatsApp for direct messaging."}],$=new Map([["all","All Apps"],["connected","Connected"],["notConnected","Not Connected"]]);function q(){const[c,g]=o.useState("ascending"),[t,p]=o.useState("all"),[l,v]=o.useState(""),y=P.sort((s,d)=>c==="ascending"?s.name.localeCompare(d.name):d.name.localeCompare(s.name)).filter(s=>t==="connected"?s.connected:t==="notConnected"?!s.connected:!0).filter(s=>s.name.toLowerCase().includes(l.toLowerCase()));return e.jsxs(e.Fragment,{children:[e.jsxs(f,{children:[e.jsx(I,{}),e.jsxs("div",{className:"ml-auto flex items-center gap-4",children:[e.jsx(k,{}),e.jsx(u,{})]})]}),e.jsxs(b,{fixed:!0,children:[e.jsxs("div",{children:[e.jsx("h1",{className:"text-2xl font-bold tracking-tight",children:"App Integrations"}),e.jsx("p",{className:"text-muted-foreground",children:"Here's a list of your apps for the integration!"})]}),e.jsxs("div",{className:"my-4 flex items-end justify-between sm:my-0 sm:items-center",children:[e.jsxs("div",{className:"flex flex-col gap-4 sm:my-4 sm:flex-row",children:[e.jsx(x,{placeholder:"Filter apps...",className:"h-9 w-40 lg:w-[250px]",value:l,onChange:s=>v(s.target.value)}),e.jsxs(r,{value:t,onValueChange:p,children:[e.jsx(i,{className:"w-36",children:e.jsx(h,{children:$.get(t)})}),e.jsxs(m,{children:[e.jsx(n,{value:"all",children:"All Apps"}),e.jsx(n,{value:"connected",children:"Connected"}),e.jsx(n,{value:"notConnected",children:"Not Connected"})]})]})]}),e.jsxs(r,{value:c,onValueChange:g,children:[e.jsx(i,{className:"w-16",children:e.jsx(h,{children:e.jsx(B,{size:18})})}),e.jsxs(m,{align:"end",children:[e.jsx(n,{value:"ascending",children:e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx(Z,{size:16}),e.jsx("span",{children:"Ascending"})]})}),e.jsx(n,{value:"descending",children:e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx(R,{size:16}),e.jsx("span",{children:"Descending"})]})})]})]})]}),e.jsx(j,{className:"shadow-sm"}),e.jsx("ul",{className:"faded-bottom no-scrollbar grid gap-4 overflow-auto pt-4 pb-16 md:grid-cols-2 lg:grid-cols-3",children:y.map(s=>e.jsxs("li",{className:"rounded-lg border p-4 hover:shadow-md",children:[e.jsxs("div",{className:"mb-8 flex items-center justify-between",children:[e.jsx("div",{className:"bg-muted flex size-10 items-center justify-center rounded-lg p-2",children:s.logo}),e.jsx(M,{variant:"outline",size:"sm",className:`${s.connected?"border border-blue-300 bg-blue-50 hover:bg-blue-100 dark:border-blue-700 dark:bg-blue-950 dark:hover:bg-blue-900":""}`,children:s.connected?"Connected":"Connect"})]}),e.jsxs("div",{children:[e.jsx("h2",{className:"mb-1 font-semibold",children:s.name}),e.jsx("p",{className:"line-clamp-2 text-gray-500",children:s.desc})]})]},s.name))})]})]})}const re=q;export{re as component};
