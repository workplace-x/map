import{j as o}from"./index-CuBDL_H4.js";const n=()=>o.jsx("div",{children:"Forms Route - Under Construction"});export{n as component};
