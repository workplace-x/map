import{j as o}from"./index-CuBDL_H4.js";const e=function(){return o.jsx("div",{children:"Gap Report feature coming soon."})};export{e as component};
