import{j as n}from"./index-CuBDL_H4.js";const t=function(){return n.jsx("div",{children:"Daily Wins feature coming soon."})};export{t as component};
