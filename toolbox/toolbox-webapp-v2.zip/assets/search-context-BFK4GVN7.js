import{b3 as a,f as d,aW as b,aa as j,ah as S,bc as w,E as A,bg as B,ay as c,j as e,Q as D,bh as z,bi as T}from"./index-CuBDL_H4.js";import{C as N,a as R,b as L,c as _,d as u,e as i,f as P}from"./command-Ca16-8Bg.js";import{B as g}from"./bot-Bmn-JysZ.js";import{F as E}from"./file-text-CoPXWk81.js";import{U as $}from"./user-Bxszi5i7.js";import{C as F}from"./circle-help-_UQahqY4.js";/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var y=a("outline","arrow-right-dashed","IconArrowRightDashed",[["path",{d:"M5 12h.5m3 0h1.5m3 0h6",key:"svg-0"}],["path",{d:"M13 18l6 -6",key:"svg-1"}],["path",{d:"M13 6l6 6",key:"svg-2"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var m=a("outline","barrier-block","IconBarrierBlock",[["path",{d:"M4 7m0 1a1 1 0 0 1 1 -1h14a1 1 0 0 1 1 1v7a1 1 0 0 1 -1 1h-14a1 1 0 0 1 -1 -1z",key:"svg-0"}],["path",{d:"M7 16v4",key:"svg-1"}],["path",{d:"M7.5 16l9 -9",key:"svg-2"}],["path",{d:"M13.5 16l6.5 -6.5",key:"svg-3"}],["path",{d:"M4 13.5l6.5 -6.5",key:"svg-4"}],["path",{d:"M17 16v4",key:"svg-5"}],["path",{d:"M5 20h4",key:"svg-6"}],["path",{d:"M15 20h4",key:"svg-7"}],["path",{d:"M17 7v-2",key:"svg-8"}],["path",{d:"M7 7v-2",key:"svg-9"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var U=a("outline","bolt","IconBolt",[["path",{d:"M13 3l0 7l6 0l-8 11l0 -7l-6 0l8 -11",key:"svg-0"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var G=a("outline","browser-check","IconBrowserCheck",[["path",{d:"M4 4m0 1a1 1 0 0 1 1 -1h14a1 1 0 0 1 1 1v14a1 1 0 0 1 -1 1h-14a1 1 0 0 1 -1 -1z",key:"svg-0"}],["path",{d:"M4 8h16",key:"svg-1"}],["path",{d:"M8 4v4",key:"svg-2"}],["path",{d:"M9.5 14.5l1.5 1.5l3 -3",key:"svg-3"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var H=a("outline","chart-bar","IconChartBar",[["path",{d:"M3 13a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v6a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1z",key:"svg-0"}],["path",{d:"M15 9a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v10a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1z",key:"svg-1"}],["path",{d:"M9 5a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v14a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1z",key:"svg-2"}],["path",{d:"M4 20h14",key:"svg-3"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var k=a("outline","checklist","IconChecklist",[["path",{d:"M9.615 20h-2.615a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h8a2 2 0 0 1 2 2v8",key:"svg-0"}],["path",{d:"M14 19l2 2l4 -4",key:"svg-1"}],["path",{d:"M9 8h4",key:"svg-2"}],["path",{d:"M9 12h2",key:"svg-3"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var O=a("outline","credit-card","IconCreditCard",[["path",{d:"M3 5m0 3a3 3 0 0 1 3 -3h12a3 3 0 0 1 3 3v8a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3z",key:"svg-0"}],["path",{d:"M3 10l18 0",key:"svg-1"}],["path",{d:"M7 15l.01 0",key:"svg-2"}],["path",{d:"M11 15l2 0",key:"svg-3"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var V=a("outline","database","IconDatabase",[["path",{d:"M12 6m-8 0a8 3 0 1 0 16 0a8 3 0 1 0 -16 0",key:"svg-0"}],["path",{d:"M4 6v6a8 3 0 0 0 16 0v-6",key:"svg-1"}],["path",{d:"M4 12v6a8 3 0 0 0 16 0v-6",key:"svg-2"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var W=a("outline","device-laptop","IconDeviceLaptop",[["path",{d:"M3 19l18 0",key:"svg-0"}],["path",{d:"M5 6m0 1a1 1 0 0 1 1 -1h12a1 1 0 0 1 1 1v8a1 1 0 0 1 -1 1h-12a1 1 0 0 1 -1 -1z",key:"svg-1"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var Q=a("outline","layout-dashboard","IconLayoutDashboard",[["path",{d:"M5 4h4a1 1 0 0 1 1 1v6a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1v-6a1 1 0 0 1 1 -1",key:"svg-0"}],["path",{d:"M5 16h4a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1v-2a1 1 0 0 1 1 -1",key:"svg-1"}],["path",{d:"M15 12h4a1 1 0 0 1 1 1v6a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1v-6a1 1 0 0 1 1 -1",key:"svg-2"}],["path",{d:"M15 4h4a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1v-2a1 1 0 0 1 1 -1",key:"svg-3"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var q=a("outline","messages","IconMessages",[["path",{d:"M21 14l-3 -3h-7a1 1 0 0 1 -1 -1v-6a1 1 0 0 1 1 -1h9a1 1 0 0 1 1 1v10",key:"svg-0"}],["path",{d:"M14 15v2a1 1 0 0 1 -1 1h-7l-3 3v-10a1 1 0 0 1 1 -1h2",key:"svg-1"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var M=a("outline","packages","IconPackages",[["path",{d:"M7 16.5l-5 -3l5 -3l5 3v5.5l-5 3z",key:"svg-0"}],["path",{d:"M2 13.5v5.5l5 3",key:"svg-1"}],["path",{d:"M7 16.545l5 -3.03",key:"svg-2"}],["path",{d:"M17 16.5l-5 -3l5 -3l5 3v5.5l-5 3z",key:"svg-3"}],["path",{d:"M12 19l5 3",key:"svg-4"}],["path",{d:"M17 16.5l5 -3",key:"svg-5"}],["path",{d:"M12 13.5v-5.5l-5 -3l5 -3l5 3v5.5",key:"svg-6"}],["path",{d:"M7 5.03v5.455",key:"svg-7"}],["path",{d:"M12 8l5 -3",key:"svg-8"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var K=a("outline","shield","IconShield",[["path",{d:"M12 3a12 12 0 0 0 8.5 3a12 12 0 0 1 -8.5 15a12 12 0 0 1 -8.5 -15a12 12 0 0 0 8.5 -3",key:"svg-0"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var J=a("outline","target","IconTarget",[["path",{d:"M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0",key:"svg-0"}],["path",{d:"M12 12m-5 0a5 5 0 1 0 10 0a5 5 0 1 0 -10 0",key:"svg-1"}],["path",{d:"M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0",key:"svg-2"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var f=a("outline","tool","IconTool",[["path",{d:"M7 10h3v-3l-3.5 -3.5a6 6 0 0 1 8 8l6 6a2 2 0 0 1 -3 3l-6 -6a6 6 0 0 1 -8 -8l3.5 3.5",key:"svg-0"}]]);/**
 * @license @tabler/icons-react v3.34.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var X=a("outline","user-cog","IconUserCog",[["path",{d:"M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0",key:"svg-0"}],["path",{d:"M6 21v-2a4 4 0 0 1 4 -4h2.5",key:"svg-1"}],["path",{d:"M19.001 19m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",key:"svg-2"}],["path",{d:"M19.001 15.5v1.5",key:"svg-3"}],["path",{d:"M19.001 21v1.5",key:"svg-4"}],["path",{d:"M22.032 17.25l-1.299 .75",key:"svg-5"}],["path",{d:"M17.27 20l-1.3 .75",key:"svg-6"}],["path",{d:"M15.97 17.25l1.3 .75",key:"svg-7"}],["path",{d:"M20.733 20l1.3 .75",key:"svg-8"}]]);/**
 * @license lucide-react v0.488.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=[["path",{d:"M2 13a2 2 0 0 0 2-2V7a2 2 0 0 1 4 0v13a2 2 0 0 0 4 0V4a2 2 0 0 1 4 0v13a2 2 0 0 0 4 0v-4a2 2 0 0 1 2-2",key:"57tc96"}]],Z=d("audio-waveform",Y);/**
 * @license lucide-react v0.488.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ee=[["path",{d:"M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3",key:"11bfej"}]],ae=d("command",ee);/**
 * @license lucide-react v0.488.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const te=[["path",{d:"M7 2h10",key:"nczekb"}],["path",{d:"M5 6h14",key:"u2x4p"}],["rect",{width:"18",height:"12",x:"3",y:"10",rx:"2",key:"l0tzu3"}]],se=d("gallery-vertical-end",te);/**
 * @license lucide-react v0.488.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=[["path",{d:"M20 7h-9",key:"3s1dr2"}],["path",{d:"M14 17H5",key:"gfn3mx"}],["circle",{cx:"17",cy:"17",r:"3",key:"18b49y"}],["circle",{cx:"7",cy:"7",r:"3",key:"dfmy0x"}]],oe=d("settings-2",le);/**
 * @license lucide-react v0.488.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=[["path",{d:"M18 21a8 8 0 0 0-16 0",key:"3ypg7q"}],["circle",{cx:"10",cy:"8",r:"5",key:"o932ke"}],["path",{d:"M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3",key:"10s06x"}]],ne=d("users-round",re),ie={teams:[{name:"Toolbox",logo:ae,plan:"Tangram Interiors"},{name:"Analytics Hub",logo:b,plan:"Business Intelligence"},{name:"AI Workspace",logo:g,plan:"AI-Powered"}],navGroups:[{title:"Overview",defaultCollapsed:!1,items:[{title:"Dashboard",url:"/",icon:Q},{title:"Daily Wins",url:"/daily-wins",icon:k},{title:"Redline Report",url:"/redline-report",icon:m},{title:"Analytics",url:"/analytics",icon:j}]},{title:"AI & Automation",defaultCollapsed:!1,items:[{title:"AI Composer",url:"/rfp-gpt",icon:Z,badge:"New"},{title:"RFP Management",url:"/rfp-management",icon:se},{title:"AI Margin Analysis",url:"/ai-margin-analysis",icon:g,badge:"Beta"},{title:"Invoice Intelligence",url:"/invoices",icon:O,badge:"AI"}]},{title:"Sales & Revenue",defaultCollapsed:!1,items:[{title:"Margin Analysis",url:"/margin-analysis",icon:H},{title:"Quotes",url:"/quotes",icon:E},{title:"Orders",url:"/orders",icon:M},{title:"Forecast",url:"/forecast",icon:S},{title:"Gap Report",url:"/gap-report",icon:m}]},{title:"Approvals & Tasks",defaultCollapsed:!1,items:[{title:"My Approvals",url:"/my-approvals",icon:k,badge:"3"},{title:"Quote Approvals",url:"/approvals",icon:J},{title:"Tasks",url:"/tasks",icon:f}]},{title:"Relationships",defaultCollapsed:!0,items:[{title:"Customers",url:"/customers",icon:w},{title:"Vendors",url:"/vendors",icon:X},{title:"Team",url:"/users",icon:ne}]},{title:"System & Data",defaultCollapsed:!0,items:[{title:"Azure Status",url:"/azure-status",icon:V,badge:"Live"},{title:"Data Sync",url:"/sync-status",icon:U},{title:"Monitoring",url:"/monitoring",icon:K},{title:"Chats",url:"/chats",icon:q}]},{title:"Configuration",defaultCollapsed:!0,items:[{title:"Profile",url:"/profile",icon:$},{title:"Settings",url:"/settings",icon:oe},{title:"Apps",url:"/apps",icon:M},{title:"Published Forms",url:"/forms/published",icon:G},{title:"Form Builder",url:"/forms/builder",icon:f},{title:"Help Center",url:"/help-center",icon:F}]}]};function ce(){const s=A(),{setTheme:n}=B(),{open:h,setOpen:o}=de(),t=c.useCallback(l=>{o(!1),l()},[o]);return e.jsxs(N,{modal:!0,open:h,onOpenChange:o,children:[e.jsx(R,{placeholder:"Type a command or search..."}),e.jsx(L,{children:e.jsxs(D,{type:"hover",className:"h-72 pr-1",children:[e.jsx(_,{children:"No results found."}),ie.navGroups.map(l=>e.jsx(u,{heading:l.title,children:l.items.map((r,C)=>{var p;return r.url?e.jsxs(i,{value:r.title,onSelect:()=>{t(()=>s({to:r.url}))},children:[e.jsx("div",{className:"mr-2 flex h-4 w-4 items-center justify-center",children:e.jsx(y,{className:"text-muted-foreground/80 size-2"})}),r.title]},`${r.url}-${C}`):(p=r.items)==null?void 0:p.map((v,I)=>e.jsxs(i,{value:v.title,onSelect:()=>{t(()=>s({to:v.url}))},children:[e.jsx("div",{className:"mr-2 flex h-4 w-4 items-center justify-center",children:e.jsx(y,{className:"text-muted-foreground/80 size-2"})}),v.title]},`${v.url}-${I}`))})},l.title)),e.jsx(P,{}),e.jsxs(u,{heading:"Theme",children:[e.jsxs(i,{onSelect:()=>t(()=>n("light")),children:[e.jsx(z,{})," ",e.jsx("span",{children:"Light"})]}),e.jsxs(i,{onSelect:()=>t(()=>n("dark")),children:[e.jsx(T,{className:"scale-90"}),e.jsx("span",{children:"Dark"})]}),e.jsxs(i,{onSelect:()=>t(()=>n("system")),children:[e.jsx(W,{}),e.jsx("span",{children:"System"})]})]})]})})]})}const x=c.createContext(null);function me({children:s}){const[n,h]=c.useState(!1);return c.useEffect(()=>{const o=t=>{t.key==="k"&&(t.metaKey||t.ctrlKey)&&(t.preventDefault(),h(l=>!l))};return document.addEventListener("keydown",o),()=>document.removeEventListener("keydown",o)},[]),e.jsxs(x.Provider,{value:{open:n,setOpen:h},children:[s,e.jsx(ce,{})]})}const de=()=>{const s=c.useContext(x);if(!s)throw new Error("useSearch has to be used within <SearchContext.Provider>");return s};export{f as I,me as S,G as a,J as b,q as c,ie as s,de as u};
