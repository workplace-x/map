import{b0 as o}from"./index-CuBDL_H4.js";const n=o;export{n as component};
